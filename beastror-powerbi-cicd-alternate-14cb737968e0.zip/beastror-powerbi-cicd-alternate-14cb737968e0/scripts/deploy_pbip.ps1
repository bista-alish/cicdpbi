# =====================================================================
# deploy-pbip.ps1
# UPDATED VERSION - Added INCREMENTAL deployment mode
# =====================================================================

# CRITICAL: Set ALL color suppression variables FIRST
$env:NO_COLOR = "1"
$env:TERM = "dumb"
$env:COLORTERM = ""

# PowerShell 7+ color suppression
if ($PSVersionTable.PSVersion.Major -ge 7) {
    $PSStyle.OutputRendering = [System.Management.Automation.OutputRendering]::PlainText
    $PSStyle.Progress.View = [System.Management.Automation.ProgressView]::Minimal
    
    # Disable all formatting colors
    $PSStyle.Formatting.Debug = ""
    $PSStyle.Formatting.Error = ""
    $PSStyle.Formatting.Verbose = ""
    $PSStyle.Formatting.Warning = ""
    $PSStyle.FileInfo.Directory = ""
    $PSStyle.FileInfo.SymbolicLink = ""
    $PSStyle.FileInfo.Executable = ""
}

# Force console settings for pipeline compatibility
try {
    $Host.UI.RawUI.BackgroundColor = [System.ConsoleColor]::Black
    $Host.UI.RawUI.ForegroundColor = [System.ConsoleColor]::White
} catch {
    # Ignore console setting errors in pipeline environments
}

# Suppress all possible color output from modules
$env:PSHOME_COLOR = "0"
$env:ANSIBLE_FORCE_COLOR = "0"

# ============= CHANGE: Dynamic workspace selection =============
# Use WORKSPACE_ID if set (for TEST/PROD), otherwise use DEV_WORKSPACE_ID
$targetWorkspaceId = if ($env:WORKSPACE_ID) { $env:WORKSPACE_ID } else { $env:DEV_WORKSPACE_ID }
# ====================================================================

# ============= NEW: Check deployment mode =============
$deploymentMode = if ($env:DEPLOYMENT_MODE) { $env:DEPLOYMENT_MODE } else { "FULL" }
Write-Host "=== Power BI PBIP Deployment Script ==="
Write-Host "Deployment Mode: $deploymentMode"
# ======================================================

Write-Host "PowerShell Version: $($PSVersionTable.PSVersion)"
Write-Host "Platform: $($PSVersionTable.Platform)"
Write-Host "Container: PowerShell on $($PSVersionTable.OS)"
Write-Host "Target Workspace ID: $targetWorkspaceId"

# Download and install FabricPS-PBIP module with error suppression
Write-Host "Setting up FabricPS-PBIP module..."
New-Item -ItemType Directory -Path ".\modules\FabricPS-PBIP" -ErrorAction SilentlyContinue | Out-Null

@("https://raw.githubusercontent.com/microsoft/Analysis-Services/master/pbidevmode/fabricps-pbip/FabricPS-PBIP.psm1",
  "https://raw.githubusercontent.com/microsoft/Analysis-Services/master/pbidevmode/fabricps-pbip/FabricPS-PBIP.psd1") | ForEach-Object {
    $fileName = Split-Path $_ -Leaf
    Write-Host "Downloading: $fileName"
    Invoke-WebRequest -Uri $_ -OutFile ".\modules\FabricPS-PBIP\$fileName" -UseBasicParsing
}

# Install required modules with suppressed output
if (-not (Get-Module Az.Accounts -ListAvailable)) {
    Write-Host "Installing Az.Accounts module..."
    Install-Module Az.Accounts -Scope CurrentUser -Force -AllowClobber -Verbose:$false -WarningAction SilentlyContinue
}

# Import the FabricPS-PBIP module with maximum suppression
Write-Host "Importing FabricPS-PBIP module..."
try {
    # Try standard import first
    Import-Module ".\modules\FabricPS-PBIP" -Force -WarningAction SilentlyContinue -Verbose:$false
    Write-Host "Module imported successfully"
} catch {
    Write-Host "Standard import failed, trying alternative method..."
    try {
        # Alternative: dot-source the module
        . ".\modules\FabricPS-PBIP\FabricPS-PBIP.psm1"
        Write-Host "Module loaded via dot-sourcing"
    } catch {
        Write-Host "Failed to load module: $($_.Exception.Message)"
        exit 1
    }
}

# Function to check if semantic model exists
function Test-SemanticModelExists {
    param(
        [string]$workspaceId,
        [string]$semanticModelName
    )
    
    try {
        $items = Invoke-FabricAPIRequest -Uri "workspaces/$workspaceId/items?type=SemanticModel" -Method Get
        $existingModel = $items | Where-Object { $_.displayName -eq $semanticModelName }
        return $existingModel
    } catch {
        return $null
    }
}

# ============= NEW: Function to get changed reports from git diff =============
function Get-ChangedReports {
    Write-Host "`n=== Checking for Changed Reports (Git Diff) ==="
    
    try {
        $defaultBranch = "develop"
        
        Write-Host "Fetching origin/$defaultBranch..."
        git fetch origin $defaultBranch 2>$null
        
        if ($LASTEXITCODE -ne 0) {
            Write-Host "WARNING: Failed to fetch origin/$defaultBranch"
            return $null
        }
        
        Write-Host "Comparing against: origin/$defaultBranch"
        
        # Get changed files in reports folder
        $changedFiles = git diff --name-only origin/$defaultBranch HEAD -- reports/ 2>$null
        
        Write-Host "Git diff exit code: $LASTEXITCODE"
        Write-Host "Files found: $($changedFiles.Count)"
        
        if (-not $changedFiles) {
            Write-Host "No changes detected in reports folder"
            return @()
        }
        
        Write-Host "Changed files detected:"
        $changedFiles | ForEach-Object { Write-Host "  - $_" }
        
        # Extract unique report folder names from changed files
        $changedReports = $changedFiles | ForEach-Object {
            if ($_ -match '^reports/([^/]+)/') {
                $matches[1]
            }
        } | Select-Object -Unique
        
        Write-Host "`nChanged reports identified:"
        $changedReports | ForEach-Object { Write-Host "  - $_" }
        Write-Host "Total changed reports: $($changedReports.Count)"
        
        return $changedReports
        
    } catch {
        Write-Host "WARNING: Could not determine changed files: $($_.Exception.Message)"
        Write-Host "Falling back to FULL deployment"
        return $null
    }
}
# =============================================================================

# Debug: Show folder structure
Write-Host "`n=== Reports Folder Analysis ==="
if (Test-Path "reports") {
    $pbipFolders = Get-ChildItem -Path "reports" -Directory
    $pbixFiles = Get-ChildItem -Path "reports" -Filter "*.pbix"
    
    Write-Host "PBIP Projects found: $($pbipFolders.Count)"
    $pbipFolders | ForEach-Object { Write-Host "  - $($_.Name)" }
    
    Write-Host "PBIX Files found: $($pbixFiles.Count)"
    $pbixFiles | ForEach-Object { Write-Host "  - $($_.Name)" }
} else {
    Write-Host "ERROR: 'reports' folder not found!"
    exit 1
}
Write-Host "=====================================`n"

# Authenticate with Service Principal - WITH MAXIMUM ERROR SUPPRESSION
Write-Host "Authenticating with Azure Service Principal..."
try {
    # Additional color suppression just for this call
    $OriginalErrorActionPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Stop'
    
    # Try to suppress any color output from the authentication
    $null = Set-FabricAuthToken -servicePrincipalId $env:CLIENT_ID -servicePrincipalSecret $env:CLIENT_SECRET -tenantId $env:TENANT_ID 2>$null
    
    $ErrorActionPreference = $OriginalErrorActionPreference
    Write-Host "Authentication successful"
} catch {
    Write-Host "Authentication failed: $($_.Exception.Message)"
    Write-Host "Full error: $($_.Exception.ToString())"
    
    # Debug info
    Write-Host "Debug info:"
    Write-Host "- CLIENT_ID length: $($env:CLIENT_ID.Length)"
    Write-Host "- TENANT_ID length: $($env:TENANT_ID.Length)"
    Write-Host "- CLIENT_SECRET length: $($env:CLIENT_SECRET.Length)"
    
    exit 1
}

# Test API connection and validate workspace
Write-Host "Validating target workspace ($targetWorkspaceId)..."
try {
    $workspace = Invoke-FabricAPIRequest -Uri "workspaces/$targetWorkspaceId" -Method Get
    Write-Host "Target workspace found: $($workspace.displayName)"
} catch {
    Write-Host "Workspace not accessible: $($_.Exception.Message)"
    exit 1
}

# Initialize counters
$successCount = 0
$failureCount = 0

# ============= NEW: Determine which reports to deploy based on mode =============
if ($deploymentMode -eq "INCREMENTAL") {
    Write-Host "`n=== INCREMENTAL DEPLOYMENT MODE ==="
    $changedReports = Get-ChangedReports
    
    if ($null -eq $changedReports) {
        # Fallback to FULL if git diff failed
        Write-Host "Git diff failed, switching to FULL deployment"
        $pbipFolders = Get-ChildItem -Path "reports" -Directory -ErrorAction SilentlyContinue
    } elseif ($changedReports.Count -eq 0) {
        Write-Host "No reports changed. Nothing to deploy."
        Write-Host "`n=== DEPLOYMENT SUMMARY ==="
        Write-Host "Deployment mode: INCREMENTAL"
        Write-Host "Changed reports: 0"
        Write-Host "Skipped deployment - no changes detected"
        Write-Host "============================="
        exit 0
    } else {
        # Filter to only changed reports
        $allFolders = Get-ChildItem -Path "reports" -Directory -ErrorAction SilentlyContinue
        $pbipFolders = $allFolders | Where-Object { $changedReports -contains $_.Name }
        Write-Host "Deploying $($pbipFolders.Count) changed report(s)"
    }
} else {
    Write-Host "`n=== FULL DEPLOYMENT MODE ==="
    $pbipFolders = Get-ChildItem -Path "reports" -Directory -ErrorAction SilentlyContinue
    Write-Host "Deploying all $($pbipFolders.Count) report(s)"
}
# =================================================================================

# Deploy PBIP projects
Write-Host "`n=== Deploying PBIP Projects ==="

foreach ($pbipFolder in $pbipFolders) {
    Write-Host "`n--- Processing PBIP: $($pbipFolder.Name) ---"
    
    # Define expected paths
    $semanticModelPath = Join-Path $pbipFolder.FullName "$($pbipFolder.Name).SemanticModel"
    $reportPath = Join-Path $pbipFolder.FullName "$($pbipFolder.Name).Report"
    
    # Validate structure
    if (!(Test-Path $semanticModelPath) -or !(Test-Path $reportPath)) {
        Write-Host "Invalid PBIP structure for: $($pbipFolder.Name)"
        $failureCount++
        continue
    }
    
    try {
        # Deploy Semantic Model
        # Check if semantic model already exists
        Write-Host "=== Checking for Existing Semantic Model ==="
        Write-Host "Parameters:"
        Write-Host "  - Workspace ID: $targetWorkspaceId"
        Write-Host "  - Model Name: '$($pbipFolder.Name)'"
        Write-Host "  - Folder Path: $($pbipFolder.FullName)"
        $existingSemanticModel = Test-SemanticModelExists -workspaceId $targetWorkspaceId -semanticModelName $pbipFolder.Name
        Write-Host "Result Analysis:"
        if ($existingSemanticModel) {
            Write-Host "    EXISTING MODEL FOUND"
            Write-Host "    - Display Name: '$($existingSemanticModel.displayName)'"
            Write-Host "    - Model ID: $($existingSemanticModel.id)"
            Write-Host "    - Item Type: $($existingSemanticModel.type)"
            Write-Host "    - Workspace ID: $($existingSemanticModel.workspaceId)"
            Write-Host "    - Description: $($existingSemanticModel.description)"
        } else {
            Write-Host " NO EXISTING MODEL"
            Write-Host " This will be a fresh deployment"
        }
        
        
        # Deploy Semantic Model
        Write-Host "Importing semantic model..."
        $semanticModelImport = Import-FabricItem -workspaceId $targetWorkspaceId -path $semanticModelPath
        Write-Host "Semantic model imported. ID: $($semanticModelImport.Id)"
        
        
        # Deploy Report
        Write-Host "Importing report..."
        $reportProperties = @{"semanticModelId" = $semanticModelImport.Id}
        $reportImport = Import-FabricItem -workspaceId $targetWorkspaceId -path $reportPath -itemProperties $reportProperties
        Write-Host "Report imported. ID: $($reportImport.Id)"
        
        Write-Host "SUCCESS: $($pbipFolder.Name)"
        $successCount++
        
    } catch {
        Write-Host "FAILED: $($pbipFolder.Name) - $($_.Exception.Message)"
        $failureCount++
    }
}

# Final summary
Write-Host "`n=== DEPLOYMENT SUMMARY ==="
Write-Host "Deployment mode: $deploymentMode"
Write-Host "Successful deployments: $successCount"
Write-Host "Failed deployments: $failureCount"
Write-Host "Total processed: $($successCount + $failureCount)"
Write-Host "============================="

if ($failureCount -gt 0) {
    Write-Host "`n Deployment completed with $failureCount failure(s)"
    exit 1
} else {
    Write-Host "`n All deployments completed successfully!"
    exit 0
}