$workspaceId = $env:POWERBI_WORKSPACE_ID

# Authenticate using Service Principal
$secureSecret = ConvertTo-SecureString $env:CLIENT_SECRET -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential($env:CLIENT_ID, $secureSecret)
Connect-PowerBIServiceAccount -ServicePrincipal -Credential $credential -Tenant $env:TENANT_ID

# Deploy changed PBIX files
$changedFiles = git diff --name-only HEAD~1 HEAD | Where-Object { $_ -like 'reports/*.pbix' }

foreach ($file in $changedFiles) {
    try {
        Write-Host "Deploying PBIX: $file"
        New-PowerBIReport -Path $file -WorkspaceId $workspaceId -ConflictAction CreateOrOverwrite
        Write-Host "Success: $file"
    } catch {
        Write-Host "Failed: $file - $($_.Exception.Message)"
    }
}
